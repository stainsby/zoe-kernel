---
name: zoe-claude-init
description: Sets up a ZOE in any Claude environment, including Cowork and Claude Code. Use once, on a new ZOE or one whose instructions are missing.
---

# Starting ZOE in a Claude environment

This is a one-off. It puts the kernel's instructions and the kernel's version into the
workspace and makes the environment load the instructions, after which the enterprise runs on
its own skills and this one is done.

The other times to run it are to repair an enterprise whose instructions have gone missing —
an install that half finished, or a workspace moved to an environment that loads them
differently — and to apply a kernel upgrade the director has approved, when the kernel's
upgrade skill calls this one to write the new instruction file and `VERSION`. Both are safe:
every step below either changes nothing or fixes a difference.

The instruction files and `VERSION` travel with this skill, in its own `assets/` folder, so
what lands in the workspace is a copy of the released text rather than anything retyped.

## What this route is

The kernel's skills run from this plugin. They are not copied into the workspace: one plugin
cache per user serves every enterprise on the machine, a plugin update replaces the skills for
all of them, and removing the plugin removes the skills and the three agents. The other route,
`hosts/claude-code/README.md` in the kernel's repository, puts the whole kernel tree in the
project and pins it; it is Claude Code only. This route works on any Claude environment and is
the weaker of the two on version control. That is acceptable because the instructions outrank
the skills, and the instructions are the part this skill pins.

## What differs between environments

**Every environment gets the same two files in the workspace**, under `.zoe/`, and may get
a third:

- `.zoe/instructions/zoe.instructions.md` — the kernel's instructions, a pinned copy. This is
  what the enterprise reads, what its index points at, and the only thing that runs from the
  workspace rather than the plugin.
- `.zoe/VERSION` — the kernel version those instructions and the plugin's skills came from.

A third file, the enterprise's own `enterprise.instructions.md` at the workspace root, is
written only if it is not already there, and left unfilled for `zoe-setup`. It is the
enterprise's, not the kernel's, which is why it does not live under `.zoe/`.

`.zoe/` is what this enterprise holds of ZOE. It is not the kernel — the skills are in the
plugin — and it is not named as if it were. The kernel's upgrade skill compares `.zoe/VERSION`
with the plugin's own `VERSION` (at the plugin's root, beside its `CHANGELOG/`), reads the
changelog entries between the two, and on the director's approval runs this skill again to
write the new files. Two index lines follow from this, for setup to record: `where the kernel
came from` is this plugin, and `where the kernel's changelog is` is
`${CLAUDE_PLUGIN_ROOT}/CHANGELOG/`, which the host
resolves to whichever plugin version is installed.

What differs is only how the environment is told to load it:

- **Claude Code** reads a `CLAUDE.md` at the workspace root every session. Add the import line
  and the instructions are unconditional, in front of the model before it decides anything.
- **Cowork** has no such file, but a Cowork *project* has an **Instructions** field — standing
  guidance applied to every session in that project. It does the same job. You cannot write it
  yourself: it is set in the project's settings, so give the person the exact line and ask them
  to paste it in.
- **Anywhere with neither**, the file still goes into the workspace and the enterprise's index
  records that every session reads it first. Say plainly that this is the weakest of the three:
  nothing but discipline puts the rules in context before the model acts, and it belongs in the
  index as a known weakness of the host.

If you cannot tell which you are, say so and ask, rather than guessing.

## Setting it up

1. **Confirm where.** State the directory you are about to write into and have the person
   confirm it is the enterprise's project root. Do not infer it from where a shell happens to
   be. If `.zoe/kernel/` already exists there, the enterprise was installed by the manual
   route with the whole kernel in the project, and this skill is not for it: stop and say so,
   rather than writing a second instruction file beside the first. If
   `kernel/instructions/zoe.instructions.md` exists with no `kernel/skills/` beside it, the
   enterprise is on the plugin layout of kernel 1.3.0: carry out the move the changelog's 1.4.0
   entry describes — the file to `.zoe/instructions/`, the empty `kernel/` removed, the old
   import line replaced — rather than writing a second copy beside the first; and once step 3
   has run, set `.zoe/VERSION` back to `1.3.0`, the version they were on, so the upgrade skill
   reads the whole span rather than the plugin's own version.

2. **See what instructions the workspace already has, and talk to the person about them.** It
   may carry its own — a `CLAUDE.md`, an `AGENTS.md`, anything either of them imports — written
   for whatever it was doing before ZOE arrived. Read them, and raise what you find.

   This is a conversation, not a form to fill in. The ZOE instructions order the charter,
   themselves, the skills and your own judgement; they say nothing about instructions that were
   already here, because the kernel cannot know what those are. So there is no rule for you to
   apply — and two sets of standing directions that quietly disagree is how a gate stops being
   enforced without anyone noticing. Work out together what should happen.

   These are the shapes such a conversation usually takes, offered as a starting point rather
   than a menu: the old instructions stay and ZOE's take precedence where they conflict; the old
   ones are cleared out first; or you both satisfy yourselves that nothing really conflicts, in
   which case say what you checked.

   Two things are yours rather than theirs. **Delete nothing yourself.** And **say plainly if
   anything already there would weaken a gate** — a direction to act without asking, to skip
   approval, to push or publish unprompted; that belongs in the conversation whether or not they
   raise it. Record whatever you settle on, so a later session is not left guessing.

3. **Put the instruction file and `VERSION` in the workspace.** Where you can run commands:

   ```sh
   mkdir -p .zoe/instructions
   cp "${CLAUDE_PLUGIN_ROOT}"/skills/zoe-claude-init/assets/*.md .zoe/instructions/
   cp "${CLAUDE_PLUGIN_ROOT}"/skills/zoe-claude-init/assets/VERSION .zoe/VERSION
   ```

   Reading the plugin's files may be refused until you are given access to them. If it is, say
   so plainly and offer the fix rather than working around it: the person approves the read
   when prompted, or runs `/add-dir ${CLAUDE_PLUGIN_ROOT}` first. Where you have no shell, read
   each file in this skill's `assets/` folder and write it into `.zoe/` under the same name —
   the `.md` files into `.zoe/instructions/`, `VERSION` beside that folder — and say that is
   what you did. Either way it is a copy: never retype the text, and never summarise or tidy it.

   **Do not go on to step 4 until both files are really there.** An import pointing at a file
   that is not there fails silently, and the enterprise then starts with no instructions and no
   gates, looking entirely normal.

   The copy is deliberate, not a link, and it is pinned: nothing replaces it but the kernel's
   upgrade skill, on the director's approval, by running this skill again. A plugin update
   replaces the skills underneath the enterprise; it does not replace these files. `VERSION`
   records which release the pinned instructions — and the skills that were current with
   them — came from, so the upgrade skill can tell what moved.

4. **Make the environment load it.** Which of these applies was settled above.

   **The enterprise's own instructions** — its standing directions, conventions and facts —
   are loaded by whichever of the three routes below applies, alongside the kernel's: a
   second `@` line in Claude Code, a second sentence in Cowork's **Instructions** field, and
   nothing to add where the environment offers neither. In every case the file is
   `enterprise.instructions.md` at the workspace root; in Claude Code the line is
   `@enterprise.instructions.md` (from `.claude/CLAUDE.md`, `@../enterprise.instructions.md`),
   and step 5 checks that the line resolves. If the file is not there, write it from
   `instructions.template.md` in `zoe-setup`'s `assets/` and leave it unfilled: `zoe-setup`
   fills it in with the director. Where you can run commands:

   ```sh
   [ -e enterprise.instructions.md ] || cp "${CLAUDE_PLUGIN_ROOT}"/skills/zoe-setup/assets/instructions.template.md enterprise.instructions.md
   ```

   Where you have no shell, read that template and write it into the workspace root under
   the name `enterprise.instructions.md`, unchanged — only if no file of that name is there.

   **In Cowork**, ask the person to open the project's settings and add this to its
   **Instructions**, then confirm they have done it before you go on:

   > This project is a ZOE enterprise. At the start of every session, before anything else,
   > read `.zoe/instructions/zoe.instructions.md` from this project's folder and follow it.
   > Then read `enterprise.instructions.md` from the same folder.

   Only the person can edit that field, so the path in it is settled for good: a later kernel
   does not move it. If the project is ever archived and re-created, the folder and its files
   survive but the field does not; say that it must be pasted again.

   You cannot set that field yourself, so do not claim it is done on their word alone — ask them
   to confirm, and say in your report that it rests on their confirmation.

   **In Claude Code**, add these two lines to the workspace's `CLAUDE.md`, creating that file
   if there is none:

   ```
   @.zoe/instructions/zoe.instructions.md
   @enterprise.instructions.md
   ```

   If a `CLAUDE.md` already exists, **add those lines and change nothing else.** Never
   overwrite a file you did not create.

   An import resolves relative to the file holding it. At the workspace root the lines above
   are right; inside `.claude/CLAUDE.md` they must read
   `@../.zoe/instructions/zoe.instructions.md` and `@../enterprise.instructions.md`.

   **Where the environment offers neither**, there is nothing to add here. Record in the
   enterprise's index that its instructions are read from the workspace at the start of every
   session, and that nothing enforces it.

5. **Check it, and give a count.** Nothing warns you when an import points at nothing.

   ```sh
   for f in CLAUDE.md .claude/CLAUDE.md; do
     [ -f "$f" ] || continue
     grep -o '^@[^ ]*instructions\.md' "$f" | while IFS= read -r l; do
       if [ -f "$(dirname "$f")/${l#@}" ]; then echo "RESOLVES  $f: $l"; else echo "DANGLING  $f: $l"; fi
     done
   done
   ls -l .zoe/instructions/zoe.instructions.md .zoe/VERSION enterprise.instructions.md
   diff .zoe/VERSION "${CLAUDE_PLUGIN_ROOT}/VERSION" && echo VERSION-MATCHES
   ```

   Where step 4 added import lines, every one must print `RESOLVES` and none `DANGLING`, and
   there must be **at least two** — the kernel's file and the enterprise's; where it added a
   project instruction, the check is that the person
   has confirmed it and that you have said the check rests on their word; where it added
   neither, the check is that the instruction file is in the workspace and complete. In every
   case `.zoe/VERSION` must exist and match the plugin's — the `diff` prints `VERSION-MATCHES`
   and nothing else. **The count is the point, not the listing** — a check that only inspects what it finds
   passes silently when it finds nothing, which is exactly what happens when the merge in step 4
   was missed. If part of that is refused, enumerate the same things with your file tools and
   say which you used. State a count and a verdict, not an impression.

## Then hand over

If you have just set the workspace up, it is a ZOE now, but a blank one: no charter, no index,
no stores. Say so, say what you found about this environment — whether it has a project
instructions file, a shell, sub-agents, durable files — and stop. Those answers belong in the
enterprise's index as its known weaknesses.

What comes next belongs to the kernel, not here: its orient skill runs first, finds no index,
and hands over to setup, where the person is interviewed as director to write the charter.
**Do not start that interview from this skill.**

While setting up: change nothing else in the workspace, never overwrite a file you did not
create, and report what this environment cannot do rather than quietly working around it.

<!-- Generated from plugins/claude/zoe-claude-init.template.md; edit that, not this. -->
