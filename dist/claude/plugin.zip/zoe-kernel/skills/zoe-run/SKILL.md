---
name: zoe-run
description: Execute the tasks and scheduled activities that are due, on schedule or on an event.
---

> ZOE Core file — read-only.

Your purpose here is to carry out the work that is due: tasks, and the
scheduled activities the index names.

Read: your skills, your state, and where your index says tasks are kept
(see `zoe-tasks`).

Do: work each task that is due, and carry out each scheduled activity the
index says is due — an audit, a measure, a check — using the skill that owns
it. Record what each produced, failures and partial results included, and
each status change, in the task store and your state as you act. Track usage
against the charter's constraints; estimate material costs before acting,
and an action whose cost you cannot estimate is gated wherever the unknown
could plausibly breach a constraint.

Dispatch: list the tasks that are due with their dependencies, and take those
whose dependencies are done, up to the `concurrency limit` in your index.
Where a task fits one agent's session and does not need your own context,
write a brief and launch a worker on the model your index maps to `worker`;
otherwise work it yourself. As each worker returns, confirm its record is
where the brief said, and checkpoint. Repeat until nothing is due.

The brief, written fresh for each worker: when it was dispatched, as a clock
reading — a worker that cannot read a clock uses it as its time; the task
text as written; its completion criterion; the charter's hard rules, and to
stop and record rather than act on anything gated; where to write its record;
what it may and may not change; and what to return.

Events: an item arriving on the director channel or wherever feedback arrives (see your
index) is an event that triggers work. It becomes a task (triaged per
`zoe-feedback` when it is feedback) and is worked when due, like any other.

Tools: when work in hand must act on the outside world and no tool recorded
in your index covers it, acquire one and record how to reach it in the index.

Obey: check the charter's hard rules at the moment of acting, not only when
planning; anything gated and unapproved waits (`## Stop and ask a director
when` in the instructions).

Hand off: where an assessment is due, the results go to assess (`zoe-assess`) — in this
session if it is already a management session, otherwise in the next one, which opens only as
your index says. A work session does not open one by its own act; it ends with its records
written.
